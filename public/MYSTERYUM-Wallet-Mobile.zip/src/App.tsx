import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { BottomNav, ActiveTab } from './components/BottomNav';
import { PortfolioView } from './components/PortfolioView';
import { SwapView } from './components/SwapView';
import { AiAgentView } from './components/AiAgentView';
import { ChatView } from './components/ChatView';
import { ExploreView } from './components/ExploreView';
import { SettingsView } from './components/SettingsView';
import { SupportPortalView } from './components/SupportPortalView';

import { SendModal } from './components/modals/SendModal';
import { ReceiveModal } from './components/modals/ReceiveModal';
import { BuyModal } from './components/modals/BuyModal';
import { StakeModal } from './components/modals/StakeModal';
import { PerpTradeModal } from './components/modals/PerpTradeModal';
import { AccountModal } from './components/modals/AccountModal';
import { BiometricUnlockModal } from './components/modals/BiometricUnlockModal';

import {
  WalletAccount,
  NetworkId,
  LanguageCode,
  TokenAsset,
  PerpPosition,
  TransactionRecord,
} from './types/wallet';
import {
  INITIAL_TOKENS,
  XSTOCKS_DATA,
  PERP_MARKETS,
  STAKING_OPTIONS,
  INITIAL_NFTS,
  MYSTERYUM_CARDS,
  INITIAL_TRANSACTIONS,
} from './data/mockData';
import {
  generateSeedPhrase,
  deriveSolanaAddressFromSeed,
} from './utils/crypto';

export default function App() {
  // Check URL pathname or query for support
  const initialTab =
    window.location.pathname.includes('/support') || window.location.hash.includes('support')
      ? 'support'
      : 'portfolio';

  const [activeTab, setActiveTab] = useState<ActiveTab>(initialTab);
  const [network, setNetwork] = useState<NetworkId>('mainnet-beta');
  const [currency, setCurrency] = useState<string>('USD');
  const [language, setLanguage] = useState<LanguageCode>('en');

  // Accounts state
  const [accounts, setAccounts] = useState<WalletAccount[]>(() => {
    const saved = localStorage.getItem('mysteryum_accounts');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        // fallback
      }
    }
    const defaultPhrase = [
      'quantum', 'cyber', 'grail', 'mystery', 'solana', 'vault',
      'shadow', 'plasma', 'future', 'energy', 'matrix', 'shield'
    ];
    const defaultAddr = deriveSolanaAddressFromSeed(defaultPhrase);
    return [
      {
        id: 'acc-1',
        name: 'Mysteryum Vault #01',
        address: defaultAddr,
        seedPhrase: defaultPhrase,
        privateKeyHex: '8c92f1b40d3a5e7819c62d0e4f3a8b7156c9a2e3d4f8b01247a3e5c9b1d6f284',
        createdAt: Date.now(),
      },
    ];
  });

  const [activeAccountId, setActiveAccountId] = useState<string>(() => accounts[0].id);

  // Core application state
  const [tokens, setTokens] = useState<TokenAsset[]>(() => {
    const saved = localStorage.getItem('mysteryum_tokens');
    return saved ? JSON.parse(saved) : INITIAL_TOKENS;
  });

  const [perpPositions, setPerpPositions] = useState<PerpPosition[]>(() => {
    const saved = localStorage.getItem('mysteryum_perps');
    return saved ? JSON.parse(saved) : [];
  });

  const [stakingOptions, setStakingOptions] = useState(() => {
    const saved = localStorage.getItem('mysteryum_staking');
    return saved ? JSON.parse(saved) : STAKING_OPTIONS;
  });

  const [transactions, setTransactions] = useState<TransactionRecord[]>(() => {
    const saved = localStorage.getItem('mysteryum_txs');
    return saved ? JSON.parse(saved) : INITIAL_TRANSACTIONS;
  });

  // Modal controls
  const [isSendOpen, setIsSendOpen] = useState(false);
  const [sendDefaultSymbol, setSendDefaultSymbol] = useState('SOL');

  const [isReceiveOpen, setIsReceiveOpen] = useState(false);
  const [isBuyOpen, setIsBuyOpen] = useState(false);

  const [isStakeOpen, setIsStakeOpen] = useState(false);
  const [stakeDefaultProvider, setStakeDefaultProvider] = useState('jito');

  const [isPerpOpen, setIsPerpOpen] = useState(false);
  const [perpDefaultSymbol, setPerpDefaultSymbol] = useState('SOL-PERP');

  const [isAccountModalOpen, setIsAccountModalOpen] = useState(false);
  const [swapDefaultFrom, setSwapDefaultFrom] = useState('SOL');

  // Biometric security states
  const [isLocked, setIsLocked] = useState<boolean>(() => {
    return localStorage.getItem('mysteryum_locked') === 'true';
  });
  const [isBiometricModalOpen, setIsBiometricModalOpen] = useState<boolean>(false);

  const handleUnlock = () => {
    setIsLocked(false);
    setIsBiometricModalOpen(false);
    localStorage.setItem('mysteryum_locked', 'false');
  };

  const handleLock = () => {
    setIsLocked(true);
    setIsBiometricModalOpen(true);
    localStorage.setItem('mysteryum_locked', 'true');
  };

  // Persistence effects
  useEffect(() => {
    localStorage.setItem('mysteryum_accounts', JSON.stringify(accounts));
  }, [accounts]);

  useEffect(() => {
    localStorage.setItem('mysteryum_tokens', JSON.stringify(tokens));
  }, [tokens]);

  useEffect(() => {
    localStorage.setItem('mysteryum_perps', JSON.stringify(perpPositions));
  }, [perpPositions]);

  useEffect(() => {
    localStorage.setItem('mysteryum_staking', JSON.stringify(stakingOptions));
  }, [stakingOptions]);

  useEffect(() => {
    localStorage.setItem('mysteryum_txs', JSON.stringify(transactions));
  }, [transactions]);

  const activeAccount = accounts.find((a) => a.id === activeAccountId) || accounts[0];
  const solToken = tokens.find((t) => t.symbol === 'SOL') || tokens[0];
  const usdcToken = tokens.find((t) => t.symbol === 'USDC') || tokens[2];

  // Action handlers
  const handleSend = (symbol: string, recipient: string, amount: number) => {
    setTokens((prev) =>
      prev.map((t) => (t.symbol === symbol ? { ...t, balance: Math.max(0, t.balance - amount) } : t))
    );

    const token = tokens.find((t) => t.symbol === symbol);
    const newTx: TransactionRecord = {
      id: `tx-${Date.now()}`,
      type: 'send',
      symbol,
      amount,
      amountUsd: amount * (token?.usdPrice || 1),
      fromAddress: activeAccount.address,
      toAddress: recipient,
      timestamp: Date.now(),
      status: 'confirmed',
      signature: '5wKzq9R1xYv4NpM8Lt62AqBsDtFvGeKnHzQjXp7R3wEa',
      feeSol: 0.000005,
    };
    setTransactions((prev) => [newTx, ...prev]);
  };

  const handleExecuteSwap = (fromSymbol: string, toSymbol: string, inAmount: number, outAmount: number) => {
    setTokens((prev) =>
      prev.map((t) => {
        if (t.symbol === fromSymbol) return { ...t, balance: Math.max(0, t.balance - inAmount) };
        if (t.symbol === toSymbol) return { ...t, balance: t.balance + outAmount };
        return t;
      })
    );

    const fromToken = tokens.find((t) => t.symbol === fromSymbol);
    const newTx: TransactionRecord = {
      id: `tx-${Date.now()}`,
      type: 'swap',
      symbol: `${fromSymbol} → ${toSymbol}`,
      amount: inAmount,
      amountUsd: inAmount * (fromToken?.usdPrice || 1),
      fromAddress: activeAccount.address,
      toAddress: 'JupiterDEXRouter11111111111111111111111111111',
      timestamp: Date.now(),
      status: 'confirmed',
      signature: '7hJq2NpM8Lt62AqBsDtFvGeKnHzQjXp7R3wEa5wKzq9R1',
      feeSol: 0.000005,
    };
    setTransactions((prev) => [newTx, ...prev]);
  };

  const handleBuyTopUp = (solAmount: number) => {
    setTokens((prev) =>
      prev.map((t) => (t.symbol === 'SOL' ? { ...t, balance: t.balance + solAmount } : t))
    );

    const newTx: TransactionRecord = {
      id: `tx-${Date.now()}`,
      type: 'receive',
      symbol: 'SOL (On-ramp Topup)',
      amount: solAmount,
      amountUsd: solAmount * solToken.usdPrice,
      fromAddress: 'MoonPaySolanaTreasury1111111111111111111111',
      toAddress: activeAccount.address,
      timestamp: Date.now(),
      status: 'confirmed',
      signature: '9qP31c4h6yT99u1iA5dF3sW7e4R2KPGM5mNxP98YF21d',
      feeSol: 0.000005,
    };
    setTransactions((prev) => [newTx, ...prev]);
  };

  const handleStake = (providerId: string, amount: number) => {
    setTokens((prev) =>
      prev.map((t) => (t.symbol === 'SOL' ? { ...t, balance: Math.max(0, t.balance - amount) } : t))
    );

    setStakingOptions((prev: any[]) =>
      prev.map((opt) => (opt.id === providerId ? { ...opt, stakedAmount: opt.stakedAmount + amount } : opt))
    );

    const newTx: TransactionRecord = {
      id: `tx-${Date.now()}`,
      type: 'stake',
      symbol: `${amount} SOL Staked`,
      amount,
      amountUsd: amount * solToken.usdPrice,
      fromAddress: activeAccount.address,
      toAddress: `${providerId.toUpperCase()}StakePool11111111111111111111111`,
      timestamp: Date.now(),
      status: 'confirmed',
      signature: '3hBm7K9pQ1xYv4NpM8Lt62AqBsDtFvGeKnHzQjXp7R3w',
      feeSol: 0.000005,
    };
    setTransactions((prev) => [newTx, ...prev]);
  };

  const handleOpenPerpPosition = (posData: Omit<PerpPosition, 'id' | 'timestamp'>) => {
    setTokens((prev) =>
      prev.map((t) => (t.symbol === 'USDC' ? { ...t, balance: Math.max(0, t.balance - posData.collateralUsd) } : t))
    );

    const newPosition: PerpPosition = {
      ...posData,
      id: `pos-${Date.now()}`,
      timestamp: Date.now(),
    };
    setPerpPositions((prev) => [newPosition, ...prev]);
  };

  const handleClosePosition = (posId: string) => {
    const pos = perpPositions.find((p) => p.id === posId);
    if (!pos) return;

    const returnAmount = Math.max(0, pos.collateralUsd + pos.pnlUsd);
    setTokens((prev) =>
      prev.map((t) => (t.symbol === 'USDC' ? { ...t, balance: t.balance + returnAmount } : t))
    );

    setPerpPositions((prev) => prev.filter((p) => p.id !== posId));
  };

  const handleCreateNewAccount = () => {
    const phrase = generateSeedPhrase();
    const address = deriveSolanaAddressFromSeed(phrase);
    const newAcc: WalletAccount = {
      id: `acc-${Date.now()}`,
      name: `Mysteryum Vault #${accounts.length + 1}`,
      address,
      seedPhrase: phrase,
      privateKeyHex: 'a' + Date.now().toString(16) + 'f8b01247a3e5c9b1d6f2848c92f1b40d3a5e7819c62d0e4',
      createdAt: Date.now(),
    };
    setAccounts((prev) => [...prev, newAcc]);
    setActiveAccountId(newAcc.id);
  };

  const handleRestoreFromPhrase = (words: string[]) => {
    const address = deriveSolanaAddressFromSeed(words);
    const restoredAcc: WalletAccount = {
      id: `acc-${Date.now()}`,
      name: `Restored Vault #${accounts.length + 1}`,
      address,
      seedPhrase: words,
      privateKeyHex: 'd3a5e7819c62d0e4f3a8b7156c9a2e3d4f8b01247a3e5c9b1d6f2848c92f1b40',
      createdAt: Date.now(),
    };
    setAccounts((prev) => [...prev, restoredAcc]);
    setActiveAccountId(restoredAcc.id);
  };

  const handleResetWallet = () => {
    localStorage.clear();
    window.location.reload();
  };

  return (
    <div className="min-h-screen bg-[#080a0f] text-slate-100 flex flex-col font-sans selection:bg-cyan-500/30 selection:text-cyan-200">
      {/* Top Header */}
      <Header
        account={activeAccount}
        network={network}
        onNetworkChange={setNetwork}
        currency={currency}
        onCurrencyChange={setCurrency}
        language={language}
        onLanguageChange={setLanguage}
        onOpenSupport={() => setActiveTab('support')}
        onOpenReceive={() => setIsReceiveOpen(true)}
        onOpenAccountModal={() => setIsAccountModalOpen(true)}
        totalBalanceUsd={tokens.reduce((acc, t) => acc + t.balance * t.usdPrice, 0)}
        isLocked={isLocked}
        onToggleLock={() => (isLocked ? setIsBiometricModalOpen(true) : handleLock())}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 pt-5">
        {activeTab === 'portfolio' && (
          <PortfolioView
            tokens={tokens}
            xStocks={XSTOCKS_DATA}
            perpMarkets={PERP_MARKETS}
            perpPositions={perpPositions}
            stakingOptions={stakingOptions}
            nfts={INITIAL_NFTS}
            cards={MYSTERYUM_CARDS}
            transactions={transactions}
            currency={currency}
            language={language}
            isLocked={isLocked}
            onTriggerUnlock={() => setIsBiometricModalOpen(true)}
            onOpenSend={(sym) => {
              if (sym) setSendDefaultSymbol(sym);
              setIsSendOpen(true);
            }}
            onOpenReceive={() => setIsReceiveOpen(true)}
            onOpenBuy={() => setIsBuyOpen(true)}
            onOpenSwap={(sym) => {
              if (sym) setSwapDefaultFrom(sym);
              setActiveTab('swap');
            }}
            onOpenStake={(pId) => {
              if (pId) setStakeDefaultProvider(pId);
              setIsStakeOpen(true);
            }}
            onOpenPerp={(sym) => {
              if (sym) setPerpDefaultSymbol(sym);
              setIsPerpOpen(true);
            }}
            onClosePosition={handleClosePosition}
          />
        )}

        {activeTab === 'swap' && (
          <SwapView
            tokens={tokens}
            onExecuteSwap={handleExecuteSwap}
            defaultFrom={swapDefaultFrom}
          />
        )}

        {activeTab === 'aiAgent' && <AiAgentView tokens={tokens} />}

        {activeTab === 'chat' && <ChatView account={activeAccount} />}

        {activeTab === 'explore' && <ExploreView />}

        {activeTab === 'settings' && (
          <SettingsView
            account={activeAccount}
            network={network}
            onNetworkChange={setNetwork}
            currency={currency}
            onCurrencyChange={setCurrency}
            language={language}
            onLanguageChange={setLanguage}
            onResetWallet={handleResetWallet}
            onOpenSupport={() => setActiveTab('support')}
            onTriggerLock={handleLock}
          />
        )}

        {activeTab === 'support' && (
          <SupportPortalView
            language={language}
            onLanguageChange={setLanguage}
          />
        )}
      </main>

      {/* Bottom Navigation */}
      <BottomNav
        activeTab={activeTab}
        onChangeTab={setActiveTab}
        language={language}
      />

      {/* Modals */}
      {isSendOpen && (
        <SendModal
          tokens={tokens}
          currency={currency}
          onClose={() => setIsSendOpen(false)}
          onSend={handleSend}
          defaultTokenSymbol={sendDefaultSymbol}
        />
      )}

      {isReceiveOpen && (
        <ReceiveModal
          account={activeAccount}
          network={network}
          onClose={() => setIsReceiveOpen(false)}
        />
      )}

      {isBuyOpen && (
        <BuyModal
          currency={currency}
          solPriceUsd={solToken.usdPrice}
          onClose={() => setIsBuyOpen(false)}
          onSimulateTopUp={handleBuyTopUp}
        />
      )}

      {isStakeOpen && (
        <StakeModal
          stakingOptions={stakingOptions}
          solBalance={solToken.balance}
          onClose={() => setIsStakeOpen(false)}
          onStake={handleStake}
          defaultProviderId={stakeDefaultProvider}
        />
      )}

      {isPerpOpen && (
        <PerpTradeModal
          markets={PERP_MARKETS}
          usdcBalance={usdcToken.balance}
          onClose={() => setIsPerpOpen(false)}
          onOpenPosition={handleOpenPerpPosition}
          defaultSymbol={perpDefaultSymbol}
        />
      )}

      {isAccountModalOpen && (
        <AccountModal
          accounts={accounts}
          activeAccount={activeAccount}
          onSelectAccount={(acc) => setActiveAccountId(acc.id)}
          onCreateNewAccount={handleCreateNewAccount}
          onRestoreFromPhrase={handleRestoreFromPhrase}
          onClose={() => setIsAccountModalOpen(false)}
        />
      )}

      {/* Simulated Biometric Unlock Screen Modal */}
      <BiometricUnlockModal
        isOpen={isBiometricModalOpen}
        walletAddress={activeAccount.address}
        accountName={activeAccount.name}
        onUnlock={handleUnlock}
        onClose={() => setIsBiometricModalOpen(false)}
        canDismiss={!isLocked}
      />
    </div>
  );
}
